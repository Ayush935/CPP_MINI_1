#ifndef FULLTIMEEMPLOYEE_H
#define FULLTIMEEMPLOYEE_H

#include <iostream>
#include "Employee.h"
#include "Grade.h"

class FullTimeEmployee : public Employee
{
private:
    std::string _project_name;
    std::string _employee_location;
    Grade _grade;
    int _bonus_prsent;

public:
    FullTimeEmployee() = default;                                   // enable default constructor
    FullTimeEmployee(const FullTimeEmployee &) = delete;            // disable Copy constructor
    FullTimeEmployee &operator=(const FullTimeEmployee &) = delete; // disable Copy assignment
    FullTimeEmployee(FullTimeEmployee &&) = delete;                 // disble move constructor
    FullTimeEmployee &operator=(FullTimeEmployee &&) = delete;      // disable move assignment
    ~FullTimeEmployee() = default;                                  // enable default destructor

    FullTimeEmployee(std::string name,
                     std::string id,
                     float salary,
                     Department *department, std::string project_name,
                     std::string employee_location,
                     Grade grade,
                     int bonus_prsent);

    float CalculateBonus() override;

    std::string projectName() const { return _project_name; }

    std::string employeeLocation() const { return _employee_location; }
    void setEmployeeLocation(const std::string &employee_location) { _employee_location = employee_location; }

    Grade grade() const { return _grade; }
    void setGrade(const Grade &grade) { _grade = grade; }

    int bonusPrsent() const { return _bonus_prsent; }
    void setBonusPrsent(int bonus_prsent) { _bonus_prsent = bonus_prsent; }

    friend std::ostream &operator<<(std::ostream &os, const FullTimeEmployee &rhs);
};

#endif // FULLTIMEEMPLOYEE_H



