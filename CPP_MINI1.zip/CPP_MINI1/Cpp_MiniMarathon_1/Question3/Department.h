#ifndef DEPARTMENT_H
#define DEPARTMENT_H

#include <iostream>

class Department
{
private:
    std::string _id;
    int _size;

public:
    Department() = default;                             // enable default constructor
    Department(const Department &) = delete;            // disable Copy constructor
    Department &operator=(const Department &) = delete; // disable Copy assignment
    Department(Department &&) = delete;                 // disble move constructor
    Department &operator=(Department &&) = delete;      // disable move assignment
    ~Department() = default;                            // enable default destructor

    Department(std::string id,
               int size);

    std::string id() const { return _id; }

    int size() const { return _size; }
    void setSize(int size) { _size = size; }

    friend std::ostream &operator<<(std::ostream &os, const Department &rhs);
};

#endif // DEPARTMENT_H
