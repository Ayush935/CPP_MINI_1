#include "Employee.h"
#include "list"
#include "Grade.h"
using Container = std::list<Employee*>;

/*
  Create 3 Object Emplyoyee in List Container
*/
void CreatObjEmplyoyee(Container &data);

/*
  Display CalculateBonus for all the functions in the container
*/
void DisplayCalculateBonusForAllInstances(const Container &data);

/*
  Function to display whether all the Emplyess in the Contaiuner have salary above 500000
*/
bool EmployeesSalaryAboveGivenSalary(const Container&data, const float& salary);

/*
  Find and Display all the department instances of all full time emplyoees
  - whose grade matches with the given grade
*/
void DisplayDepartments(const Container&data,const Grade _grade );

/*
  Return the project name of employees whose ID mathches with given id
*/
std::string FindProjectName(const Container&data, std::string employeeId);

/*
  Delete THe objects in the container
*/
void DeleteObj(Container &data);


