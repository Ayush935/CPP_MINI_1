#include "Functionalities.h"
#include "FullTimeEmployee.h"
#include "ContainerEmptyDataException.h"
#include "InvalidValueException.h"


void CreatObjEmplyoyee(Container &data)
{
    data.push_back(new FullTimeEmployee("Ayush", "AD213", 80000.0f, new Department("IS123", 5), "ML", "Pune", Grade::A, 50));
    data.push_back(new FullTimeEmployee("Bob", "AD214", 8000.0f, new Department("IS124", 7), "TRAIN", "Delhi", Grade::B, 5));
    data.push_back(new FullTimeEmployee("Bobby", "AD215", 180000.0f, new Department("IS125", 10), "ROBOTSP", "Nagpur", Grade::C, 80));
}

void DisplayCalculateBonusForAllInstances(const Container &data)
{
    if (data.empty())
    {
        throw ContainerEmptyDataException("Container Data is empty");
    }
    int count = 0;
    for (Employee *ptr : data)
    {
        if (ptr)
        {
            count++;
            std::cout << "Employee " << count << " Bonus is ";
            std::cout << ptr->CalculateBonus() << std::endl;
        }
    }
    std::cout << std::endl;
}

bool EmployeesSalaryAboveGivenSalary(const Container &data, const float &salary)
{
    if (data.empty())
    {
        throw ContainerEmptyDataException("Container Data is empty");
    }

    if (salary < 0)
    {
        throw InvalidValueException("Salary Cannot be less than 0");
    }

    for (Employee *ptr : data)
    {
        if (ptr && ptr->salary() > salary)
        {
            return true;
        }
    }

    return false;
}

void DisplayDepartments(const Container &data, const Grade _grade)
{
    if (data.empty())
    {
        throw ContainerEmptyDataException("Container Data is empty");
    }

    int count = 0;
    for (Employee *ptr : data)
    {
        if (ptr)
        {
            FullTimeEmployee *fptr = dynamic_cast<FullTimeEmployee *>(ptr);
            if (fptr && fptr->grade() == _grade)
            {
                count++;
                std::cout << *(ptr->department()) << std::endl;
            }
        }
    }

    if (count == 0)
    {
        throw InvalidValueException("Sorry No such instances available with given grade");
    }
}

std::string FindProjectName(const Container &data, std::string employeeId)
{
    if (data.empty())
    {
        throw ContainerEmptyDataException("Container Data is empty");
    }

    int count = 0;
    std::string projectName = "";
    for (Employee *ptr : data)
    {
        if (ptr && ptr->id() == employeeId)
        {
            count++;
            FullTimeEmployee *fptr = dynamic_cast<FullTimeEmployee *>(ptr);
            if (fptr)
            {

                projectName = fptr->projectName();
            }
        }
    }

    if (count == 0)
    {
        throw InvalidValueException("Sorry No such Employee Id matches");
    }

    return projectName;
}

void DeleteObj(Container &data)
{
    if (data.empty())
    {
        throw ContainerEmptyDataException("Container Data is empty");
    }

    for (Employee *ptr : data)
    {
        if (ptr)
        {
            if (ptr->department())
            {
                delete ptr->department();
            }

            delete ptr;
        }
    }
}
