#include "Functionalities.h"
#include "ContainerEmptyDataException.h"
#include "InvalidValueException.h"

int main(){
    Container data;
    CreatObjEmplyoyee(data);

    try
    {
        std::cout<<"Displaying all the instances Bonus"<<std::endl;
        DisplayCalculateBonusForAllInstances(data);

        std::cout<<"All the Employees having salary above 50000, 1 for true and 0 for false "
        <<EmployeesSalaryAboveGivenSalary(data,50000)<<std::endl;
        std::cout<<std::endl;

        std::cout<<"Display Departments of the employee whose Grade match with given grade"<<std::endl;
        DisplayDepartments(data,Grade::A );
        std::cout<<std::endl;

        std::cout<<"Project Name of the employee that matches with given id "<<FindProjectName(data,"AD213" )<<std::endl;
        std::cout<<std::endl;

        DeleteObj(data);
    }
    catch(ContainerEmptyDataException& e)
    {
        std::cerr << e.what() << '\n';
    }
    catch(InvalidValueException& e)
    {
        std::cerr << e.what() << '\n';
    }
    
}