#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <iostream>
#include "Department.h"

class Employee
{
private:
    std::string _name;
    std::string _id;
    float _salary;
    Department *_department;

public:
    Employee() = default;                           // enable default constructor
    Employee(const Employee &) = delete;            // disable Copy constructor
    Employee &operator=(const Employee &) = delete; // disable Copy assignment
    Employee(Employee &&) = delete;                 // disble move constructor
    Employee &operator=(Employee &&) = delete;      // disable move assignment
    virtual ~Employee() = default;                          // enable default destructor

    Employee(std::string name,
             std::string id,
             float salary,
             Department *department);

    std::string name() const { return _name; }
    void setName(const std::string &name) { _name = name; }

    std::string id() const { return _id; }

    float salary() const { return _salary; }
    void setSalary(float salary) { _salary = salary; }

    Department *department() const { return _department; }
    void setDepartment(Department *department) { _department = department; }

    friend std::ostream &operator<<(std::ostream &os, const Employee &rhs);

    virtual float CalculateBonus() = 0;
};

#endif // EMPLOYEE_H
