#include "FullTimeEmployee.h"
std::ostream &operator<<(std::ostream &os, const FullTimeEmployee &rhs) {
    os << static_cast<const Employee &>(rhs)
       << " _project_name: " << rhs._project_name
       << " _employee_location: " << rhs._employee_location
       << " _grade: " << static_cast<int>(rhs._grade)
       << " _bonus_prsent: " << rhs._bonus_prsent;
    return os;
}

FullTimeEmployee::FullTimeEmployee(std::string name, std::string id, float salary, Department *department, std::string project_name, std::string employee_location, Grade grade, int bonus_prsent)
   :Employee(name,id,salary,department), _project_name{project_name},_employee_location{employee_location},_grade{grade},_bonus_prsent{bonus_prsent}
{
}

float FullTimeEmployee::CalculateBonus()
{
    if(_grade==Grade::A){
        return _bonus_prsent*salary();
    }
    else if(_grade==Grade::B){
        return 0.5*salary();
    }

    return 0.25*salary();
}
