#ifndef ORDER_H
#define ORDER_H

#include <iostream>
#include "OrderType.h"

class Order
{
private:
    std::string _id;
    float _value;
    OrderType _type;
    float _discount;
    
public:
    Order() = default;  // enable default constructor
    Order(const Order&) = delete;  //disable Copy constructor
    Order& operator=(const Order&)=delete;  //disable Copy assignment
    Order(Order &&)=delete; // disble move constructor
    Order& operator=(Order&&)=delete;   //disable move assignment
    ~Order() = default; //enable default destructor
    
    Order(std::string id,float value,OrderType type,float discount);
    std::string id() const { return _id; }

    float value() const { return _value; }
    void setValue(float value) { _value = value; }

    OrderType type() const { return _type; }
    void setType(const OrderType &type) { _type = type; }

    float discount() const { return _discount; }
    void setDiscount(float discount) { _discount = discount; }

    friend std::ostream &operator<<(std::ostream &os, const Order &rhs);
};

#endif // ORDER_H
