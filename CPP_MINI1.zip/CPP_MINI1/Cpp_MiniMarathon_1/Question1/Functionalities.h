#include <list>
#include "Order.h"

using Container = std::list<Order*>;

/*
  Crate 5 objects of order class
  - store their address in list container
*/
void CreateObjOrder(Container &data);

/*
  Return the Order ID
  - whose Discount is the lowest
*/
std::string IdWithLowestDiscount(const Container &data);

/*
  Return the Order Type
  - whose ID matches with the order ID
*/
OrderType FindTypeMatchWithId(const Container&data, const std::string id);

/*
  Return the average of all the Order values in container
*/
float FindAverageOfOrderValue(const Container&data);

/*
  Return the last N instances from the container
*/
Container ReturnLastNinstances( Container&data, const int N);

/*
  Delete the objects in the container
*/
void DeleteObjOrder(Container &data);



