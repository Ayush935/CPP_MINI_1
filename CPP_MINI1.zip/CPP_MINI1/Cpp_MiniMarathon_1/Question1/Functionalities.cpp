#include "Functionalities.h"
#include "ContainerEmptyDataException.h"
#include "InvalidValueException.h"

void CreateObjOrder(Container &data)
{
    data.push_back(new Order("IS123",250.25f,OrderType::COD,25.5f));
    data.push_back(new Order("IS124",150.25f,OrderType::PAID,5.5f)); 
    data.push_back(new Order("IS125",750.25f,OrderType::PROMOTION,125.5f));
    data.push_back(new Order("IS126",950.25f,OrderType::PAID,250.5f));
    data.push_back(new Order("IS127",550.25f,OrderType::COD,25.5f));
}

std::string IdWithLowestDiscount(const Container &data)
{
    if(data.empty()){
        throw ContainerEmptyDataException("Data is empty in the container");
    }
    
    float discount = data.front()->discount();
    for(Order* ptr: data){
        if(ptr && ptr->discount()<discount){
            discount = ptr->discount();
        }
    }

    
    std::string id = "";
    for(Order* ptr: data){
        if(ptr && ptr->discount()==discount){
            
            id= ptr->id();
            break;
        }
    }
    
    return id;
    
}

OrderType FindTypeMatchWithId(const Container &data, const std::string id)
{
    if(data.empty()){
        throw ContainerEmptyDataException("Data is empty in the container");
    }

    int count = 0;
    OrderType type ;
    for(Order* ptr: data){
        if(ptr && ptr->id()==id){
            count++;
            type = ptr->type();
            break;
        }
    }

    if(count == 0){
        throw ContainerEmptyDataException("Sorry No such Id is available");
    }

    return type;
}

float FindAverageOfOrderValue(const Container &data)
{
    if(data.empty()){
        throw ContainerEmptyDataException("Data is empty in the container");
    }
    
    float sum = 0;
    for(Order* ptr: data){
        if(ptr ){
            sum = sum+ ptr->value();
        }
    }

    return sum/data.size();
    
}

Container ReturnLastNinstances( Container &data, const int N)
{
    if(data.empty()){
        throw ContainerEmptyDataException("Data is empty in the container");
    }

    if(N<0 || N>data.size()){
        throw InvalidValueException("N Value is invalid ");
    }

    Container result;
    int count = 0;
    for(Container::reverse_iterator itr=data.rbegin();itr!=data.rend();++itr){
        count++;
        result.push_back(*itr);
        if(count==N){
            break;
        }
    }

    if(result.empty()){
        throw ContainerEmptyDataException("Result data is empty");
    }

    return result;
}

void DeleteObjOrder(Container &data)
{
    if(data.empty()){
        throw ContainerEmptyDataException("Data is empty in the container");
    }

    for(Order* ptr: data){
        delete ptr;
    }
}
