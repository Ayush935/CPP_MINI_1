#include "Functionalities.h"
#include "ContainerEmptyDataException.h"
#include "InvalidValueException.h"

int main(){
    Container data;
    CreateObjOrder(data);

    try
    {
        std::cout<<"ID with the lowest discount in Order "<<IdWithLowestDiscount(data)<<std::endl;
        std::cout<<std::endl;
  
        OrderType type = FindTypeMatchWithId(data,"IS123");
        std::cout<<"In OrderType 0 is PADI, 1 is COD,2 is promotion"<<std::endl;
        std::cout<<"Type that matches with given id "<<static_cast<int>(type)<<std::endl;
        std::cout<<std::endl;

        std::cout<<"Average of all the order values is "<<FindAverageOfOrderValue(data)<<std::endl;

        std::cout<<"Last N instances are "<<std::endl;
        for(Order*ptr : ReturnLastNinstances(data,3)){
            std::cout<<*ptr<<std::endl;
        }

        DeleteObjOrder(data);

    }
    catch( ContainerEmptyDataException& e)
    {
        std::cerr << e.what() << '\n';
    }
    catch( InvalidValueException& e)
    {
        std::cerr << e.what() << '\n';
    }
    
}