#include "Device.h"
std::ostream &operator<<(std::ostream &os, const Device &rhs) {
    os << "_deviceP_id: " << rhs._deviceP_id
       << " _type: " << static_cast<int>(rhs._type)
       << " _device_battery_level: " << rhs._device_battery_level
       << " _device_driver: " << *(rhs._device_driver);
    return os;
}

Device::Device(std::string deviceP_id, DeviceType type, int device_battery_level, DeviceDriver *device_driver)
   : _deviceP_id{deviceP_id},_type{type},_device_battery_level{device_battery_level},_device_driver{device_driver}
{
}

float Device::_batter_brain_factor()
{
    if(_type==DeviceType::ACCESSORY || _type==DeviceType::INFOTAINMENT){
        return 0.25;
    }

    if(_type==DeviceType::SAFETY && _device_battery_level>50){
        return 50;
    } 

    return 0.4;
}
