#ifndef CONTAINEREMPTYEXCEPTION_H
#define CONTAINEREMPTYEXCEPTION_H

#include <stdexcept>

class ContainerEmptyDataException  : std::exception
{
private:
    std::string _msg;
public:
    explicit ContainerEmptyDataException(std::string msg) : _msg(msg) {}
    ContainerEmptyDataException() = default;  // enable default constructor
    ContainerEmptyDataException(const ContainerEmptyDataException&) = delete;  //disable Copy constructor
    ContainerEmptyDataException& operator=(const ContainerEmptyDataException&)=delete;  //disable Copy assignment
    ContainerEmptyDataException(ContainerEmptyDataException &&)=delete; // disble move constructor
    ContainerEmptyDataException& operator=(ContainerEmptyDataException&&)=delete;   //disable move assignment
    ~ContainerEmptyDataException() = default; //enable default destructor
    std::string what() {return _msg; }// getter for _msg
};

#endif // CONTAINEREMPTYEXCEPTION_H


