#ifndef INVALIDVALUEEXCEPTION_H
#define INVALIDVALUEEXCEPTION_H

#include <stdexcept>

class InvalidValueException  : std::exception
{
private:
    std::string _msg;
public:
    explicit InvalidValueException(std::string msg) : _msg(msg) {}
    InvalidValueException() = default;  // enable default constructor
    InvalidValueException(const InvalidValueException&) = delete;  //disable Copy constructor
    InvalidValueException& operator=(const InvalidValueException&)=delete;  //disable Copy assignment
    InvalidValueException(InvalidValueException &&)=delete; // disble move constructor
    InvalidValueException& operator=(InvalidValueException&&)=delete;   //disable move assignment
    ~InvalidValueException() = default; //enable default destructor
    std::string what() {return _msg; }// getter for _msg
};


#endif // INVALIDVALUEEXCEPTION_H
