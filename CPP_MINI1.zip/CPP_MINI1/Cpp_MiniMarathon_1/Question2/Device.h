#ifndef DEVICE_H
#define DEVICE_H

#include <iostream>
#include "DeviceType.h"
#include "DeviceDriver.h"

class Device
{
private:
    std::string _deviceP_id;
    DeviceType _type;
    int _device_battery_level;
    DeviceDriver *_device_driver;

public:
    Device() = default;                         // enable default constructor
    Device(const Device &) = delete;            // disable Copy constructor
    Device &operator=(const Device &) = delete; // disable Copy assignment
    Device(Device &&) = delete;                 // disble move constructor
    Device &operator=(Device &&) = delete;      // disable move assignment
    ~Device() = default;                        // enable default destructor

    Device(std::string deviceP_id,
           DeviceType type,
           int device_battery_level,
           DeviceDriver *device_driver);

    std::string devicePId() const { return _deviceP_id; }

    DeviceType type() const { return _type; }
    void setType(const DeviceType &type) { _type = type; }

    int deviceBatteryLevel() const { return _device_battery_level; }
    void setDeviceBatteryLevel(int device_battery_level) { _device_battery_level = device_battery_level; }

    DeviceDriver *deviceDriver() const { return _device_driver; }
    void setDeviceDriver(DeviceDriver *device_driver) { _device_driver = device_driver; }

    friend std::ostream &operator<<(std::ostream &os, const Device &rhs);

    float _batter_brain_factor();
};

#endif // DEVICE_H
