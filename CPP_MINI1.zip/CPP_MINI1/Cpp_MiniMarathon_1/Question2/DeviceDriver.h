#ifndef DEVICEDRIVER_H
#define DEVICEDRIVER_H

#include <iostream>
#include "ReleaseQuarter.h"

class DeviceDriver
{
private:
    std::string _version_number;
    ReleaseQuarter _release_quarter;
    float _size_in_bytes;

public:
    DeviceDriver() = default;                               // enable default constructor
    DeviceDriver(const DeviceDriver &) = delete;            // disable Copy constructor
    DeviceDriver &operator=(const DeviceDriver &) = delete; // disable Copy assignment
    DeviceDriver(DeviceDriver &&) = delete;                 // disble move constructor
    DeviceDriver &operator=(DeviceDriver &&) = delete;      // disable move assignment
    ~DeviceDriver() = default;                              // enable default destructor

    DeviceDriver(std::string version_number,
                 ReleaseQuarter release_quarter,
                 float size_in_bytes);

    std::string versionNumber() const { return _version_number; }

    ReleaseQuarter releaseQuarter() const { return _release_quarter; }
    void setReleaseQuarter(const ReleaseQuarter &release_quarter) { _release_quarter = release_quarter; }

    float sizeInBytes() const { return _size_in_bytes; }
    void setSizeInBytes(float size_in_bytes) { _size_in_bytes = size_in_bytes; }

    friend std::ostream &operator<<(std::ostream &os, const DeviceDriver &rhs);
};

#endif // DEVICEDRIVER_H
