#include "Functionalities.h"
#include "ContainerEmptyDataException.h"
#include "InvalidValueException.h"

int main(){
    Container data;
    CreateObjDevice(data);

    try
    {
        std::cout<<"Device IDs batter brain factor less than 0.4"<<std::endl;
        for(std::string value: FindDeviceId(data,0.4)){
            std::cout<<value<<std::endl;
        }
        std::cout<<std::endl;

        std::cout<<"All Devices have same Device type yes or no (1 for yes, 0 for No) "
        <<DeviceInstancesSameDeviceType(data)<<std::endl;
        std::cout<<std::endl;

        DisplayFunctionLowHighSizeBytes(data);

        std::cout<<"Version Number whose device id mathces with procided id "<<FindVersonNumber(data,"IS123")<<std::endl;

        DeleteObjDevice(data);

    }
    catch(ContainerEmptyDataException& e)
    {
        std::cerr << e.what() << '\n';
    }
    catch(InvalidValueException& e)
    {
        std::cerr << e.what() << '\n';
    }
    
}