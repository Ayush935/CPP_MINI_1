#include <vector>
#include "Device.h"

using Container = std::vector<Device*>;
using Container1 = std::vector<std::string>;

/*
  Create 5 Objects of Device 
*/
void CreateObjDevice(Container &data);

/*
  Find Device Id's in container
  - whose Device battery brain factor is less than 0.4
*/
Container1 FindDeviceId(const Container&data,float batteryBrainFactor);

/*
  Check whether all objects in container have same device type
*/
bool DeviceInstancesSameDeviceType(const Container&data);

/*
  Display Lowest and highest size in bytes whose release water is Q1 OR Q2
*/
void DisplayFunctionLowHighSizeBytes(const Container&data);

/*
  Find the Version number matches with device id provided
*/
std::string FindVersonNumber(const Container&data,std::string deviceId);

/*
  Delete objects in container
*/
void DeleteObjDevice(Container &data);