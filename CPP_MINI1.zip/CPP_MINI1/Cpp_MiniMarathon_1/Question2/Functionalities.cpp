#include "Functionalities.h"
#include "ContainerEmptyDataException.h"
#include "InvalidValueException.h"

void CreateObjDevice(Container &data)
{
    data.push_back(new Device("IS123", DeviceType::ACCESSORY, 55, new DeviceDriver("W123", ReleaseQuarter::Q1, 25.5)));
    data.push_back(new Device("IS124", DeviceType::INFOTAINMENT, 35, new DeviceDriver("W124", ReleaseQuarter::Q2, 15.5)));
    data.push_back(new Device("IS125", DeviceType::SAFETY, 95, new DeviceDriver("W125", ReleaseQuarter::Q3, 205.5)));
    data.push_back(new Device("IS126", DeviceType::ACCESSORY, 35, new DeviceDriver("W126", ReleaseQuarter::Q4, 245.5)));
    data.push_back(new Device("IS127", DeviceType::ACCESSORY, 65, new DeviceDriver("W127", ReleaseQuarter::Q1, 25.5)));
}

Container1 FindDeviceId(const Container &data, float batteryBrainFactor)
{
    if(data.empty()){
        throw ContainerEmptyDataException("Data is empty");
    }


    Container1 result;
    for(Device*ptr : data){
        if(ptr && ptr->_batter_brain_factor()<batteryBrainFactor){
            result.push_back(ptr->devicePId());
        }
    }

    if(result.empty()){
        throw ContainerEmptyDataException("No such Data is available");
    }

    return result;
}

bool DeviceInstancesSameDeviceType(const Container &data)
{
    if(data.empty()){
        throw ContainerEmptyDataException("Data is empty");
    }
    
    int count=0;
    DeviceType type = data[0]->type();
    for(Device*ptr :data){
        if(ptr && ptr->type()==type){
            count++;
        }
    }
    if(count == data.size()){
        return true;
    }

    return false;
}

void DisplayFunctionLowHighSizeBytes(const Container &data)
{
    if(data.empty()){
        throw ContainerEmptyDataException("Data is empty");
    }
    
    int count =0;
    float LowestSizeBytes = data[0]->deviceDriver()->sizeInBytes();
    float HighestSizeBytes = data[0]->deviceDriver()->sizeInBytes();
    for(Device*ptr :data){
        if(ptr && (ptr->deviceDriver()->releaseQuarter()==ReleaseQuarter::Q1 || ptr->deviceDriver()->releaseQuarter()==ReleaseQuarter::Q2)){
            count++;
            if(LowestSizeBytes>ptr->deviceDriver()->sizeInBytes()){
                 LowestSizeBytes = ptr->deviceDriver()->sizeInBytes();
            }
            if(HighestSizeBytes<ptr->deviceDriver()->sizeInBytes()){
                 HighestSizeBytes = ptr->deviceDriver()->sizeInBytes();
            }
        }
    }

    if(count==0){
        throw InvalidValueException("Sorry no instances have Release Quarter Q1 and Q2");
    }

    std::cout<<"Lowest Size in Bytes for Q1 AND Q2 "<<LowestSizeBytes<<std::endl;
    std::cout<<"Highest Size in Bytes for Q1 AND Q2 "<<HighestSizeBytes<<std::endl;
    

}

std::string FindVersonNumber(const Container &data, std::string deviceId)
{
    if(data.empty()){
        throw ContainerEmptyDataException("Data is empty");
    }
    
    int count = 0;
    std::string AnswerVersonNumber = "";
    for(Device* ptr: data){
        if(ptr && ptr->devicePId()==deviceId){
            count++;
            AnswerVersonNumber = ptr->deviceDriver()->versionNumber();
        } 
    }

    if(count==0){
        throw InvalidValueException("Sorry No Device id MATCHES with id provided");
    }

    return AnswerVersonNumber;
}

void DeleteObjDevice(Container &data)
{
    if(data.empty()){
        throw ContainerEmptyDataException("Data is empty");
    }

    for(Device* ptr: data){
        if(ptr){
           delete ptr->deviceDriver();
           delete ptr;
        }
    }
}
